<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "student") {
    header("Location: ../login.php");
    exit();
}

$search = trim($_GET["search"] ?? "");

if ($search != "") {
    $like = "%" . $search . "%";
    $stmt = $conn->prepare(
        "SELECT internships.*, companies.company_name
        FROM internships
        JOIN companies ON internships.company_id = companies.id
        WHERE internships.status = 'Open'
        AND (internships.title LIKE ? OR internships.location LIKE ? OR internships.skills LIKE ?)
        ORDER BY internships.id DESC"
    );
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $internships = $stmt->get_result();
} else {
    $internships = $conn->query(
        "SELECT internships.*, companies.company_name
        FROM internships
        JOIN companies ON internships.company_id = companies.id
        WHERE internships.status = 'Open'
        ORDER BY internships.id DESC"
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internships - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="applications.php">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div><div class="badge">OPPORTUNITIES</div><h1>Find Internships</h1><p>Search for internships that match your skills and interests.</p></div>
        </div>

        <form class="search-box" method="GET">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search title, location or skills">
            <button class="button primary" type="submit">Search</button>
        </form>

        <div class="cards-grid">
            <?php if ($internships->num_rows == 0): ?>
                <div class="panel"><p>No open internships found.</p></div>
            <?php endif; ?>

            <?php while ($row = $internships->fetch_assoc()): ?>
                <article class="internship-card">
                    <div class="card-top">
                        <span class="status open">OPEN</span>
                        <span><?php echo htmlspecialchars($row["location"]); ?></span>
                    </div>
                    <h2><?php echo htmlspecialchars($row["title"]); ?></h2>
                    <p class="company-name"><?php echo htmlspecialchars($row["company_name"]); ?></p>
                    <p><?php echo htmlspecialchars($row["description"]); ?></p>
                    <div class="tags"><?php echo htmlspecialchars($row["skills"]); ?></div>
                    <a class="button primary full" href="apply.php?id=<?php echo $row["id"]; ?>">View & Apply</a>
                </article>
            <?php endwhile; ?>
        </div>
    </main>
</body>
</html>
