<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "student") {
    header("Location: ../login.php");
    exit();
}

$stmt = $conn->prepare(
    "SELECT applications.*, internships.title, companies.company_name
    FROM applications
    JOIN students ON applications.student_id = students.id
    JOIN internships ON applications.internship_id = internships.id
    JOIN companies ON internships.company_id = companies.id
    WHERE students.user_id = ?
    ORDER BY applications.applied_at DESC"
);
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$applications = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links"><a href="dashboard.php">Dashboard</a><a href="profile.php">Profile</a><a href="internships.php">Internships</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div><div class="badge">TRACKING</div><h1>My Applications</h1><p>Follow the current status of every internship application.</p></div>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>Internship</th><th>Company</th><th>Applied On</th><th>Status</th></tr></thead>
                <tbody>
                    <?php if ($applications->num_rows == 0): ?>
                        <tr><td colspan="4">You have not applied for any internship yet.</td></tr>
                    <?php endif; ?>

                    <?php while ($row = $applications->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row["title"]); ?></td>
                            <td><?php echo htmlspecialchars($row["company_name"]); ?></td>
                            <td><?php echo date("d M Y", strtotime($row["applied_at"])); ?></td>
                            <td><span class="status <?php echo strtolower(str_replace(" ", "-", $row["status"])); ?>"><?php echo htmlspecialchars($row["status"]); ?></span></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
