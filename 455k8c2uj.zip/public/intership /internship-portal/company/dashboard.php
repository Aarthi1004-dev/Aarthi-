<?php
session_start();
require_once "../config/database.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] != "company") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();

$company_id = $company["id"];

$q1 = $conn->prepare("SELECT COUNT(*) AS total FROM internships WHERE company_id = ?");
$q1->bind_param("i", $company_id);
$q1->execute();
$total_internships = $q1->get_result()->fetch_assoc()["total"];

$q2 = $conn->prepare(
    "SELECT COUNT(*) AS total FROM applications
    JOIN internships ON applications.internship_id = internships.id
    WHERE internships.company_id = ?"
);
$q2->bind_param("i", $company_id);
$q2->execute();
$total_applications = $q2->get_result()->fetch_assoc()["total"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - InternHub</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav class="navbar">
        <a class="brand" href="dashboard.php">Intern<span>Hub</span></a>
        <div class="nav-links"><a href="add_internship.php">Add Internship</a><a href="internships.php">My Internships</a><a href="applicants.php">Applicants</a><a href="../logout.php">Logout</a></div>
    </nav>

    <main class="container">
        <div class="page-heading">
            <div><div class="badge">COMPANY DASHBOARD</div><h1>Welcome, <?php echo htmlspecialchars($company["company_name"]); ?></h1><p>Publish opportunities and manage student applications.</p></div>
            <a class="button primary" href="add_internship.php">+ Add Internship</a>
        </div>

        <section class="stats">
            <div class="stat-card"><span>My Internships</span><strong><?php echo $total_internships; ?></strong></div>
            <div class="stat-card"><span>Applications</span><strong><?php echo $total_applications; ?></strong></div>
        </section>

        <section class="panel">
            <h2>Recruitment workflow</h2>
            <div class="workflow">
                <span>Applied</span><span>→</span><span>Under Review</span><span>→</span><span>Shortlisted</span><span>→</span><span>Interview</span><span>→</span><span>Selected / Rejected</span>
            </div>
        </section>
    </main>
</body>
</html>
